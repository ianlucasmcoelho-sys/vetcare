import { formatDate, localDateInput } from "../utils/date";
import { recordBelongsToPatient } from '../utils/patientRecords';
import { loadPatientContext } from '../services/patientContext';
import useQuickCreate from '../hooks/useQuickCreate';
import React, { useState, useEffect } from "react";
import { 
  FiPlus, FiSearch, FiPrinter, FiEdit2, FiTrash2, 
  FiX, FiCalendar, FiUser, FiActivity, FiFileText, 
  FiInfo, FiThermometer, FiBarChart, FiMic, FiMicOff 
} from "react-icons/fi";
import { MdOutlinePets } from "react-icons/md";
import { apiGet, apiPost, apiPut, apiDelete } from "../services/api";
import { usePermission } from "../hooks/usePermission";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import MedicalRecordPreview from "../components/MedicalRecordPreview";
import Pagination from "../components/Pagination";
import "./HistoricoMedico.css";

export default function Prontuarios() {
  const { can } = usePermission();
  const podeEditar = can("editarProntuarios");
  
  // Estados de Controle
  const [printRecord, setPrintRecord] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [busca, setBusca] = useState("");
  const [editId, setEditId] = useState(null);
  const [animalSelecionado, setAnimalSelecionado] = useState(null);
  
  // Estados de IA e Áudio
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const recognitionRef = React.useRef(null);
  
  // Estados de Paginação
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Estados de Dados
  const [prontuarios, setProntuarios] = useState([]);
  const [animais, setAnimais] = useState([]);
  const [veterinarios, setVeterinarios] = useState([]);

  // Estado do Formulário (Alinhado com o Banco de Dados)
  const [form, setForm] = useState({
    animal_id: "",
    pet_nome: "",
    tutor_nome: "",
    veterinario: "",
    veterinario_id: "",
    data_visita: localDateInput(),
    peso: "",
    temperatura: "",
    proxima_visita: "",
    sintomas: "",
    diagnostico: "",
    tratamento: "",
    prescricoes: "",
    observacoes: ""
  });

  useQuickCreate(async context => { const {animal, tutor} = await loadPatientContext(context); if (animal) setForm(previous => ({...previous, animal_id: String(animal.id), pet_nome: animal.nome, tutor_nome: tutor?.nome || ''})); setShowModal(true); }, podeEditar);

  const carregarDados = async () => {
    try {
      setLoading(true);
      const [prontRes, animaisRes, tutorsRes] = await Promise.all([
        apiGet("/prontuarios"),
        apiGet("/animais"),
        apiGet("/responsaveis")
      ]);

      if (prontRes.ok) setProntuarios(await prontRes.json());
      const tutors = tutorsRes?.ok ? await tutorsRes.json() : [];
      if (animaisRes.ok) setAnimais((await animaisRes.json()).map(animal => ({...animal, tutor_nome: tutors.find(tutor => String(tutor.id) === String(animal.responsavel_id))?.nome || ''})));

      // Carregar veterinários (Admin/Recepcionista geralmente têm acesso)
      try {
        const usersRes = await apiGet("/agendamentos/profissionais");
        if (usersRes && usersRes.ok) {
          const usersData = await usersRes.json();
          setVeterinarios(usersData.filter(u => u.perfil === 'veterinario' || u.perfil === 'admin'));
        }
      } catch (e) {
        console.warn("Acesso limitado à lista de veterinários");
      }
    } catch (err) {
      console.error("Erro ao sincronizar dados:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarDados();
  }, []);

  // Resetar página ao buscar
  useEffect(() => {
    setCurrentPage(1);
  }, [busca]);

  // Handlers de Seleção e Busca
  const handlePetSelect = async (patientId) => {
    const animal = animais.find(a => String(a.id) === String(patientId));
    if (animal) {
      setForm(prev => ({ 
        ...prev, 
        pet_nome: animal.nome, 
        animal_id: animal.id 
      }));
      
      // Buscar tutor vinculado
      if (animal.responsavel_id) {
        const res = await apiGet(`/responsaveis/${animal.responsavel_id}`);
        if (res && res.ok) {
          const tutor = await res.json();
          setForm(prev => ({ ...prev, tutor_nome: tutor.nome }));
        }
      }
    } else {
      setForm(prev => ({ ...prev, pet_nome: '', tutor_nome: '', animal_id: "" }));
    }
  };

  const handleVetSelect = (vetNome) => {
    const vet = veterinarios.find(v => v.nome === vetNome);
    if (vet) {
      setForm(prev => ({ ...prev, veterinario: vet.nome, veterinario_id: vet.id }));
    } else {
      setForm(prev => ({ ...prev, veterinario: vetNome, veterinario_id: "" }));
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  // Persistência
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.pet_nome || !form.tutor_nome) {
      alert("Por favor, preencha o nome do Pet e do Tutor.");
      return;
    }

    setLoading(true);
    try {
      const url = editId ? `/prontuarios/${editId}` : "/prontuarios";
      const res = editId ? await apiPut(url, form) : await apiPost(url, form);
      
      if (res && res.ok) {
        await carregarDados();
        fecharModal();
      } else {
        const error = await res.json();
        alert(`Erro ao salvar: ${error.details || error.error}`);
      }
    } catch (err) {
      alert("Falha na comunicação com o servidor.");
    } finally {
      setLoading(false);
    }
  };

  const fecharModal = () => {
    setForm({
      animal_id: "", pet_nome: "", tutor_nome: "", veterinario: "", veterinario_id: "",
      data_visita: localDateInput(),
      peso: "", temperatura: "", proxima_visita: "",
      sintomas: "", diagnostico: "", tratamento: "", prescricoes: "", observacoes: ""
    });
    setEditId(null);
    setShowModal(false);
  };

  // Funções de Inteligência Artificial e Reconhecimento de Voz
  const iniciarDitado = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Seu navegador não suporta reconhecimento de voz. Tente usar o Google Chrome.");
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.lang = 'pt-BR';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = true; // Continua escutando mesmo se houver pausas

    let textoFinal = "";

    recognition.onstart = () => {
      setIsRecording(true);
    };

    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          textoFinal += event.results[i][0].transcript + " ";
        }
      }
    };

    recognition.onerror = (event) => {
      console.error("Erro no reconhecimento de voz: ", event.error);
      setIsRecording(false);
      alert("Erro ao capturar voz: " + event.error);
    };

    recognition.onend = async () => {
      setIsRecording(false);
      if (textoFinal.trim() !== "") {
        setIsProcessingAI(true);
        try {
          // Enviar o texto para o backend estruturar via Gemini
          const response = await apiPost('/ai/prontuario', { textoBruto: textoFinal });
          if (response.ok) {
            const data = await response.json();
            
            // Atualizar o formulário com os dados retornados pela IA, 
            // sem apagar o que já foi preenchido manualmente
            setForm(prev => ({
              ...prev,
              sintomas: prev.sintomas ? prev.sintomas + "\n" + (data.sintomas || "") : (data.sintomas || ""),
              diagnostico: prev.diagnostico ? prev.diagnostico + "\n" + (data.diagnostico || "") : (data.diagnostico || ""),
              tratamento: prev.tratamento ? prev.tratamento + "\n" + (data.tratamento || "") : (data.tratamento || ""),
              prescricoes: prev.prescricoes ? prev.prescricoes + "\n" + (data.prescricoes || "") : (data.prescricoes || ""),
              observacoes: prev.observacoes ? prev.observacoes + "\n" + (data.observacoes || "") : (data.observacoes || ""),
            }));
            
            alert("✅ O Prontuário foi preenchido pela Inteligência Artificial!");
          } else {
            console.error("Erro na API de IA");
            alert("Houve um problema ao processar a Inteligência Artificial. O texto capturado foi:\n\n" + textoFinal);
          }
        } catch (error) {
          console.error("Falha na comunicação com a IA", error);
          alert("Falha na conexão com o servidor de Inteligência Artificial.");
        } finally {
          setIsProcessingAI(false);
        }
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const pararDitado = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
  };

  const abrirEdicao = (pront) => {
    setForm({ ...pront });
    setEditId(pront.id);
    setShowModal(true);
  };

  const deletarProntuario = async (id) => {
    if (window.confirm("Tem certeza que deseja excluir permanentemente este prontuário?")) {
      const res = await apiDelete(`/prontuarios/${id}`);
      if (res && res.ok) carregarDados();
    }
  };

  const gerarPDF = (pront) => {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    
    // Cabeçalho
    doc.setFontSize(20);
    doc.setTextColor(44, 62, 80);
    doc.text("HISTÓRICO MÉDICO VETERINÁRIO", pageWidth / 2, 20, { align: "center" });
    
    doc.setFontSize(10);
    doc.setTextColor(120);
    doc.text(`VetCare SaaS - Registro de Atendimento Clínico`, pageWidth / 2, 28, { align: "center" });

    // Tabela de Dados do Paciente
    autoTable(doc, {
      startY: 40,
      head: [['IDENTIFICAÇÃO DO PACIENTE', 'VALOR']],
      body: [
        ['NOME DO PET', pront.pet_nome],
        ['TUTOR RESPONSÁVEL', pront.tutor_nome],
        ['DATA DO ATENDIMENTO', pront.data_visita],
        ['MÉDICO VETERINÁRIO', pront.veterinario || "N/A"],
        ['PESO', pront.peso ? `${pront.peso} kg` : "N/A"],
        ['TEMPERATURA', pront.temperatura ? `${pront.temperatura} °C` : "N/A"],
      ],
      theme: 'striped',
      headStyles: { fillColor: [15, 118, 110] }
    });

    // Tabela de Evolução Clínica
    autoTable(doc, {
      startY: doc.lastAutoTable.finalY + 10,
      head: [['DETALHAMENTO CLÍNICO', '']],
      body: [
        ['SINTOMAS / QUEIXAS', pront.sintomas || "Nenhum relato"],
        ['DIAGNÓSTICO', pront.diagnostico || "Em investigação"],
        ['CONDUTA / TRATAMENTO', pront.tratamento || "Não informado"],
        ['PRESCRIÇÕES (MEDICAÇÃO)', pront.prescricoes || "Nenhuma"],
        ['OBSERVAÇÕES ADICIONAIS', pront.observacoes || "Nenhuma"],
        ['RETORNO PREVISTO', pront.proxima_visita || "Não agendado"],
      ],
      theme: 'grid',
      headStyles: { fillColor: [15, 118, 110] },
      columnStyles: { 0: { fontStyle: 'bold', cellWidth: 50 } }
    });

    doc.save(`Prontuario_${pront.pet_nome}_${pront.data_visita}.pdf`);
  };

  // Filtragem e Agrupamento
  const prontuariosFiltrados = prontuarios.filter(p =>
    p.pet_nome?.toLowerCase().includes(busca.toLowerCase()) ||
    p.diagnostico?.toLowerCase().includes(busca.toLowerCase()) ||
    p.tutor_nome?.toLowerCase().includes(busca.toLowerCase())
  );

  // Agrupar animais que possuem prontuário
  const animaisComProntuario = animais.filter(a => 
    prontuarios.some(p => recordBelongsToPatient(p, a))
  );

  const listaAnimaisFiltrada = animaisComProntuario.filter(a =>
    a.nome?.toLowerCase().includes(busca.toLowerCase())
  );

  // Lógica de Paginação (Geral ou por Animal)
  const dadosParaExibir = animalSelecionado 
    ? prontuariosFiltrados.filter(p => recordBelongsToPatient(p, animalSelecionado))
    : listaAnimaisFiltrada;

  const totalPages = Math.ceil(dadosParaExibir.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const itensExibidos = dadosParaExibir.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div className="prontuario-container fade-in">
      {printRecord && <MedicalRecordPreview records={[printRecord]} onClose={() => setPrintRecord(null)} onDownload={() => gerarPDF(printRecord)} />}
      <div className="page-header">
        <div className="header-info">
          {animalSelecionado ? (
            <button className="back-link-btn" onClick={() => setAnimalSelecionado(null)}>
              <FiX /> <span>Prontuários / {animalSelecionado.nome}</span>
            </button>
          ) : (
            <>
              <h1 className="page-title">Prontuários Médicos</h1>
              <p className="page-subtitle">Histórico clínico organizado por paciente</p>
            </>
          )}
        </div>
        <div className="header-actions">
          {podeEditar && (
            <button className="btn-primary" onClick={() => setShowModal(true)}>
              <FiPlus /> <span>Novo Atendimento</span>
            </button>
          )}
        </div>
      </div>

      <div className="prontuario-card">
        {!animalSelecionado && (
          <div className="search-section v-glass-panel reveal-up" style={{animationDelay: "0.1s"}}>
            <div className="search-wrapper">
              <FiSearch className="search-icon" />
              <input 
                className="search-input"
                placeholder="Pesquisar por nome do animal..." 
                value={busca} 
                onChange={(e) => setBusca(e.target.value)} 
              />
            </div>
          </div>
        )}

        {loading && prontuarios.length === 0 ? (
          <div className="loading-grid">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="skeleton-card" style={{ height: '180px', background: '#f1f5f9', borderRadius: '14px', animation: 'shimmer 1.5s infinite', margin: '20px' }} />
            ))}
          </div>
        ) : dadosParaExibir.length === 0 ? (
          <div className="empty-state">
            <FiFileText size={64} />
            <h3>Nenhum prontuário encontrado</h3>
            <p>Comece registrando um novo atendimento para seus pacientes.</p>
          </div>
        ) : !animalSelecionado ? (
          // LISTA DE ANIMAIS (PADRÃO DO SISTEMA)
          <div className="animais-grid">
            {itensExibidos.map(animal => (
              <div key={animal.id} className="animal-card-item" role="button" tabIndex={0} onClick={() => setAnimalSelecionado(animal)} onKeyDown={event => { if (['Enter', ' '].includes(event.key)) { event.preventDefault(); setAnimalSelecionado(animal); } }} style={{ cursor: 'pointer' }}>
                <div className="animal-card-header">
                  <div className="animal-avatar">
                    <MdOutlinePets />
                  </div>
                  <div className="animal-info">
                    <h3 className="animal-nome">{animal.nome}</h3>
                    <span className="badge-categoria">{animal.especie} • {animal.raca}</span>
                  </div>
                </div>
                <div className="animal-card-body">
                  <div className="info-row">
                    <FiActivity size={14} />
                    <span className="info-label">Atendimentos:</span>
                    <span className="info-value">{prontuarios.filter(p => recordBelongsToPatient(p, animal)).length} registros</span>
                  </div>
                  <div className="info-row">
                    <FiCalendar size={14} />
                    <span className="info-label">Última Visita:</span>
                    <span className="info-value">
                      {formatDate(prontuarios.filter(p => recordBelongsToPatient(p, animal)).sort((a,b) => new Date(b.data_visita) - new Date(a.data_visita))[0]?.data_visita)}
                    </span>
                  </div>
                </div>
                <div className="animal-card-footer">
                  <span style={{ fontSize: '11px', fontWeight: '700', color: 'var(--primary)' }}>VER HISTÓRICO COMPLETO</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          // LISTA DE REGISTROS DO ANIMAL (PADRONIZADO)
          <div className="records-list">
            {itensExibidos.map((p) => (
              <div key={p.id} className="prontuario-card-item fade-in">
                <div className="prontuario-card-header">
                  <div className="prontuario-info">
                    <h3 className="prontuario-nome">Visita em {formatDate(p.data_visita)}</h3>
                    <div className="prontuario-tags">
                      <span className="tag-tutor"><FiUser size={12} /> Dr(a). {p.veterinario}</span>
                    </div>
                  </div>
                  <div className="prontuario-header-actions">
                    <button onClick={() => setPrintRecord(p)} className="action-icon" title="Imprimir prontuário" aria-label="Imprimir prontuário">
                      <FiPrinter size={14} />
                    </button>
                    {podeEditar && (
                      <>
                        <button onClick={() => abrirEdicao(p)} className="action-icon" title="Editar">
                          <FiEdit2 size={14} />
                        </button>
                        <button onClick={() => deletarProntuario(p.id)} className="action-icon delete-btn" title="Excluir">
                          <FiTrash2 size={14} />
                        </button>
                      </>
                    )}
                  </div>
                </div>
                
                <div className="prontuario-card-body">
                  <div className="medical-grid">
                    <div className="medical-info-box warning">
                      <label><FiActivity /> DIAGNÓSTICO</label>
                      <p>{p.diagnostico || "Não concluído"}</p>
                    </div>
                    <div className="medical-info-box">
                      <label><FiInfo /> SINTOMAS</label>
                      <p>{p.sintomas || "Nenhum informado"}</p>
                    </div>
                    <div className="medical-info-box info">
                      <label><FiFileText /> TRATAMENTO</label>
                      <p>{p.tratamento || "Não informado"}</p>
                    </div>
                    <div className="medical-info-box success">
                      <label><FiFileText /> PRESCRIÇÕES</label>
                      <p>{p.prescricoes || "Nenhuma medicação registrada"}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {totalPages > 1 && (
          <Pagination 
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            totalItems={dadosParaExibir.length}
            itemsPerPage={itemsPerPage}
          />
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={fecharModal}>
          <div className="modal-content large" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title-wrapper">
                <FiFileText className="title-icon" />
                <div>
                  <h2>{editId ? "Editar Atendimento" : "Novo Atendimento"}</h2>
                  <p>Preencha os dados clínicos do paciente</p>
                </div>
              </div>
              <button onClick={fecharModal} className="modal-close"><FiX /></button>
            </div>

            <form onSubmit={handleSubmit} className="modal-form">
              <div className="form-scroll-area">
                <div className="form-section">
                  <h3 className="section-title">Dados Básicos</h3>
                  <div className="form-grid">
                    <div className="input-group">
                      <label>NOME DO PET *</label>
                      <select
                        aria-label="Paciente do prontuário"
                        value={form.animal_id || ''}
                        onChange={e => handlePetSelect(e.target.value)} 
                        required 
                      >
                        <option value="">Selecione um paciente</option>
                        {animais.map(a => <option key={a.id} value={a.id}>{a.nome} · {a.tutor_nome || 'Tutor não informado'} · #{a.id}</option>)}
                      </select>
                    </div>

                    <div className="input-group">
                      <label>TUTOR *</label>
                      <input 
                        placeholder="Nome do responsável"
                        value={form.tutor_nome} 
                        onChange={handleChange} 
                        name="tutor_nome" 
                        required 
                      />
                    </div>

                    <div className="input-group">
                      <label>MÉDICO VETERINÁRIO</label>
                      <input 
                        list="vets-list"
                        placeholder="Selecionar profissional"
                        value={form.veterinario} 
                        onChange={e => handleVetSelect(e.target.value)} 
                        name="veterinario" 
                      />
                      <datalist id="vets-list">
                        {veterinarios.map(v => <option key={v.id} value={v.nome} />)}
                      </datalist>
                    </div>

                    <div className="input-group">
                      <label>DATA DA VISITA *</label>
                      <input 
                        type="date" 
                        value={form.data_visita} 
                        onChange={handleChange} 
                        name="data_visita" 
                        required 
                      />
                    </div>

                    <div className="input-group small">
                      <label>PESO (KG)</label>
                      <input 
                        type="number" step="0.1"
                        placeholder="0.0"
                        value={form.peso} 
                        onChange={handleChange} 
                        name="peso" 
                      />
                    </div>

                    <div className="input-group small">
                      <label>TEMP. (°C)</label>
                      <input 
                        type="number" step="0.1"
                        placeholder="38.5"
                        value={form.temperatura} 
                        onChange={handleChange} 
                        name="temperatura" 
                      />
                    </div>
                  </div>
                </div>

                <div className="form-section">
                  <div className="section-header-ai">
                    <h3 className="section-title" style={{ margin: 0 }}>Evolução Clínica</h3>
                    
                    <button 
                      type="button" 
                      className={`btn-ai-dictation ${isRecording ? 'recording' : ''}`}
                      onClick={isRecording ? pararDitado : iniciarDitado}
                      disabled={isProcessingAI}
                    >
                      {isProcessingAI ? (
                        <><div className="ai-spinner"></div> Processando IA...</>
                      ) : isRecording ? (
                        <><FiMicOff /> Parar Ditado</>
                      ) : (
                        <><FiMic /> Ditar com IA</>
                      )}
                    </button>
                  </div>
                  
                  {isRecording && (
                    <div className="recording-indicator">
                      <div className="pulse-dot"></div> 
                      Escutando o microfone... Pressione "Parar Ditado" quando concluir.
                    </div>
                  )}

                  <div className="form-grid full">
                    <div className="input-group">
                      <label>SINTOMAS / QUEIXA PRINCIPAL</label>
                      <textarea 
                        rows="2" 
                        placeholder="Relato do tutor e observações iniciais..."
                        value={form.sintomas} 
                        onChange={handleChange} 
                        name="sintomas" 
                      />
                    </div>

                    <div className="input-group">
                      <label>DIAGNÓSTICO</label>
                      <textarea 
                        rows="2" 
                        placeholder="Conclusão ou suspeita clínica..."
                        value={form.diagnostico} 
                        onChange={handleChange} 
                        name="diagnostico" 
                      />
                    </div>

                    <div className="input-group">
                      <label>TRATAMENTO REALIZADO</label>
                      <textarea 
                        rows="2" 
                        placeholder="Procedimentos, exames solicitados e conduta..."
                        value={form.tratamento} 
                        onChange={handleChange} 
                        name="tratamento" 
                      />
                    </div>

                    <div className="input-group highlight">
                      <label>PRESCRIÇÕES (PARA O TUTOR)</label>
                      <textarea 
                        rows="3" 
                        placeholder="Receituário: Medicamentos, doses e horários..."
                        value={form.prescricoes} 
                        onChange={handleChange} 
                        name="prescricoes" 
                      />
                    </div>

                    <div className="input-group half">
                      <label>PRÓXIMA VISITA</label>
                      <input 
                        type="date" 
                        value={form.proxima_visita} 
                        onChange={handleChange} 
                        name="proxima_visita" 
                      />
                    </div>

                    <div className="input-group">
                      <label>OBSERVAÇÕES INTERNAS</label>
                      <textarea 
                        rows="2" 
                        placeholder="Notas adicionais não visíveis na prescrição principal..."
                        value={form.observacoes} 
                        onChange={handleChange} 
                        name="observacoes" 
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" onClick={fecharModal} className="btn-cancel">Cancelar</button>
                <button type="submit" className="btn-save" disabled={loading}>
                  {loading ? "Processando..." : (editId ? "Atualizar Histórico" : "Salvar Atendimento")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
